const UserDashboardTest = () => {
  return (
    <div className="min-h-screen bg-white p-6">
      <h1 className="text-2xl font-bold">UserDashboard Test</h1>
      <p>If you can see this, the basic component works.</p>
    </div>
  )
}

export default UserDashboardTest